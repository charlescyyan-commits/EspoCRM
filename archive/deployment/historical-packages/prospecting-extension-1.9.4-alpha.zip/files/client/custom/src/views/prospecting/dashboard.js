Espo.define('custom:views/prospecting/dashboard', 'view', function (Dep) {
    return Dep.extend({
        template: 'custom:prospecting/dashboard',

        events: {
            'click [data-action="open-search"]': 'actionOpenSearch',
        },

        actionOpenSearch: function () {
            this.getRouter().navigate('ProspectingSearch', {trigger: true});
        },
    });
});
