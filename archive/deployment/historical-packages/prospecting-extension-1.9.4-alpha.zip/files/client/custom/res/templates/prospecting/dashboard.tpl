<div class="row">
    <div class="col-sm-3">
        <div class="panel panel-default">
            <div class="panel-heading"><strong>Prospecting</strong></div>
            <div class="list-group">
                <a class="list-group-item active" href="#ProspectingDashboard"><span class="fas fa-binoculars"></span> Dashboard</a>
                <a class="list-group-item" data-action="open-search" href="#ProspectingSearch"><span class="fas fa-search"></span> Search</a>
                <a class="list-group-item" href="#SearchJob"><span class="fas fa-list"></span> Search Jobs</a>
                <a class="list-group-item" href="#ProspectPool"><span class="fas fa-layer-group"></span> Prospect Pool</a>
                <a class="list-group-item" href="#SearchStrategy"><span class="fas fa-sitemap"></span> Search Strategy</a>
            </div>
        </div>
    </div>
    <div class="col-sm-9">
        <div class="page-header"><h3>Prospecting Dashboard</h3></div>
        <div class="row">
            <div class="col-sm-4"><div class="panel panel-default"><div class="panel-heading">Today's Discovery</div><div class="panel-body"><h3 class="text-muted">—</h3><small>Existing Search Jobs appear in Search Jobs.</small></div></div></div>
            <div class="col-sm-4"><div class="panel panel-default"><div class="panel-heading">Master Prospects</div><div class="panel-body"><h3 class="text-muted">—</h3><small>Available through Prospect Pool.</small></div></div></div>
            <div class="col-sm-4"><div class="panel panel-default"><div class="panel-heading">Website Research</div><div class="panel-body"><h3 class="text-muted">—</h3><small>Read-only foundation status.</small></div></div></div>
        </div>
        <div class="row">
            <div class="col-sm-4"><div class="panel panel-default"><div class="panel-heading">Pending Research</div><div class="panel-body"><span class="text-muted">Use the Prospect Pool Research filter.</span></div></div></div>
            <div class="col-sm-4"><div class="panel panel-default"><div class="panel-heading">Completed Research</div><div class="panel-body"><span class="text-muted">Use the Prospect Pool list.</span></div></div></div>
            <div class="col-sm-4"><div class="panel panel-default"><div class="panel-heading">Recent Jobs</div><div class="panel-body"><a href="#SearchJob">Open Search Jobs</a></div></div></div>
        </div>
    </div>
</div>
