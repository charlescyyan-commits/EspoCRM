<?php

namespace Espo\Modules\Prospecting\Classes\Select\Lead\PrimaryFilters;

use Espo\Core\Select\Primary\Filter;
use Espo\ORM\Query\SelectBuilder;

/**
 * A-tier prospecting leads: opportunity score >= 80.
 */
class PeTierA implements Filter
{
    public function apply(SelectBuilder $queryBuilder): void
    {
        $queryBuilder->where([
            'peOpportunityScoreV4>=' => 80,
        ]);
    }
}
