<?php

declare(strict_types=1);

namespace Espo\Modules\Prospecting\Services;

use DateTimeImmutable;
use Espo\Core\Acl;
use Espo\Core\Exceptions\BadRequest;
use Espo\Core\Exceptions\Forbidden;
use Espo\Entities\User;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;

/**
 * Sole writer of SendExecution.status (ADR-C18 / adr-c18-sendexecution-v1).
 *
 * Bridge/result adapters must hand off terminal provider outcomes via
 * applyProviderOutcome() or transition(); they must not set status directly.
 */
class SendExecutionTransitionService
{
    public const STATUS_CREATED = 'CREATED';
    public const STATUS_READY = 'READY';
    public const STATUS_SENT = 'SENT';
    public const STATUS_FAILED = 'FAILED';
    public const STATUS_CANCELLED = 'CANCELLED';

    public const ACTION_PREPARE = 'sendExecution.prepare';
    public const ACTION_RECORD_SENT = 'sendExecution.recordSent';
    public const ACTION_RECORD_FAILED = 'sendExecution.recordFailed';
    public const ACTION_RETRY = 'sendExecution.retry';
    public const ACTION_CANCEL = 'sendExecution.cancel';

    public const GOVERNANCE_MARKER = 'adr-c18-sendexecution-v1';
    public const RECOVERY_GOVERNANCE_MARKER = 'adr-c18-sendexecution-v2';

    /** @var list<string> */
    private const CANCEL_REASONS = ['IGNORED', 'ABANDONED', 'DUPLICATE', 'OTHER'];

    /** @var array<string, list<string>> */
    private const VALID_TRANSITIONS = [
        self::STATUS_CREATED => [self::STATUS_READY],
        self::STATUS_READY => [self::STATUS_SENT, self::STATUS_FAILED, self::STATUS_CANCELLED],
        self::STATUS_FAILED => [self::STATUS_READY, self::STATUS_CANCELLED],
        self::STATUS_SENT => [],
        self::STATUS_CANCELLED => [],
    ];

    /** @var array<string, array<string, string>> */
    private const TRANSITION_ACTIONS = [
        self::STATUS_CREATED => [
            self::STATUS_READY => self::ACTION_PREPARE,
        ],
        self::STATUS_READY => [
            self::STATUS_SENT => self::ACTION_RECORD_SENT,
            self::STATUS_FAILED => self::ACTION_RECORD_FAILED,
            self::STATUS_CANCELLED => self::ACTION_CANCEL,
        ],
        self::STATUS_FAILED => [
            self::STATUS_READY => self::ACTION_RETRY,
            self::STATUS_CANCELLED => self::ACTION_CANCEL,
        ],
    ];

    public function __construct(
        private EntityManager $entityManager,
        private Acl $acl,
        private User $user,
    ) {}

    public function validateTransition(string $currentStatus, string $targetStatus): bool
    {
        $this->assertKnownStatus($currentStatus);
        $this->assertKnownStatus($targetStatus);

        return in_array($targetStatus, self::VALID_TRANSITIONS[$currentStatus], true);
    }

    /**
     * Resolves the ADR action key required for a status edge.
     */
    public function resolveAction(string $currentStatus, string $targetStatus): string
    {
        if (!$this->validateTransition($currentStatus, $targetStatus)) {
            throw new BadRequest("SendExecution transition {$currentStatus} -> {$targetStatus} is not allowed.");
        }

        $action = self::TRANSITION_ACTIONS[$currentStatus][$targetStatus] ?? null;
        if (!is_string($action) || $action === '') {
            throw new BadRequest("SendExecution transition {$currentStatus} -> {$targetStatus} has no authorization action.");
        }

        return $action;
    }

    /**
     * Authorizes a workflow action for the current user against the execution record.
     */
    public function authorize(Entity $execution, string $action): void
    {
        if ($execution->getEntityType() !== 'SendExecution') {
            throw new BadRequest('SendExecution transition requires a SendExecution entity.');
        }

        if (!$this->acl->checkEntityEdit($execution)) {
            throw new Forbidden();
        }

        $knownActions = [
            self::ACTION_PREPARE,
            self::ACTION_RECORD_SENT,
            self::ACTION_RECORD_FAILED,
            self::ACTION_RETRY,
            self::ACTION_CANCEL,
        ];
        if (!in_array($action, $knownActions, true)) {
            throw new BadRequest('Unsupported SendExecution workflow action.');
        }

        // WP1.1 foundation: edit ACL + known action key. Role bindings land with
        // metadata policy under GOVERNANCE_MARKER in a later WP.
        if ($this->user->isAdmin()) {
            return;
        }
    }

    /**
     * Provider-outcome handoff for bridge/result adapters.
     *
     * Owns READY→SENT / READY→FAILED. When the bridge delivers against CREATED or
     * FAILED, promotes to READY first so the ADR matrix remains the sole status
     * state machine. Provider-trace fields are applied on the terminal save.
     *
     * @param array{
     *   providerName?: string|null,
     *   providerMessageId?: string|null,
     *   lastError?: string|null,
     *   failureCategory?: string|null,
     *   retryCount?: int,
     *   now?: DateTimeImmutable|string
     * } $providerTrace
     */
    public function applyProviderOutcome(Entity $execution, string $targetStatus, array $providerTrace = []): Entity
    {
        if ($execution->getEntityType() !== 'SendExecution') {
            throw new BadRequest('SendExecution provider outcome requires a SendExecution entity.');
        }
        if (!in_array($targetStatus, [self::STATUS_SENT, self::STATUS_FAILED], true)) {
            throw new BadRequest('Provider outcome handoff only supports SENT or FAILED.');
        }

        $options = ['skipAuthorization' => true];
        if (array_key_exists('now', $providerTrace)) {
            $options['now'] = $providerTrace['now'];
        }

        $currentStatus = (string) ($execution->get('status') ?: self::STATUS_CREATED);
        if ($currentStatus === self::STATUS_CREATED) {
            $this->transition($execution, self::STATUS_READY, $options);
        } elseif ($currentStatus === self::STATUS_FAILED) {
            // Connector may redeliver after a prior failure; re-arm without the
            // operator retry-limit gate used by FAILED→READY workflow actions.
            $this->transition($execution, self::STATUS_READY, $options + [
                'skipRetryLimit' => true,
            ]);
        } elseif ($currentStatus !== self::STATUS_READY) {
            throw new BadRequest(
                "Provider outcome handoff cannot run from status {$currentStatus}."
            );
        }

        $this->applyProviderTraceFields($execution, $providerTrace);

        return $this->transition($execution, $targetStatus, $options);
    }

    /**
     * @param array{
     *   now?: DateTimeImmutable|string,
     *   skipAuthorization?: bool,
     *   skipRetryLimit?: bool,
     *   workflowAuthorizationChecked?: bool,
     *   reason?: string|null
     * } $options
     */
    public function transition(Entity $execution, string $targetStatus, array $options = []): Entity
    {
        if ($execution->getEntityType() !== 'SendExecution') {
            throw new BadRequest('SendExecution transition requires a SendExecution entity.');
        }

        $currentStatus = (string) ($execution->get('status') ?: self::STATUS_CREATED);
        if (!$this->validateTransition($currentStatus, $targetStatus)) {
            throw new BadRequest("SendExecution transition {$currentStatus} -> {$targetStatus} is not allowed.");
        }

        if (
            ($options['skipAuthorization'] ?? false) !== true
            && ($options['workflowAuthorizationChecked'] ?? false) !== true
        ) {
            $this->authorize($execution, $this->resolveAction($currentStatus, $targetStatus));
        }

        if (
            $currentStatus === self::STATUS_FAILED
            && $targetStatus === self::STATUS_READY
            && ($options['skipRetryLimit'] ?? false) !== true
        ) {
            $this->assertRetryAllowed($execution);
        }

        $now = $this->resolveNow($options);
        $reason = $targetStatus === self::STATUS_CANCELLED
            ? $this->normalizeCancelReason($options['reason'] ?? null)
            : null;
        return $this->entityManager->getTransactionManager()->run(
            function () use ($execution, $currentStatus, $targetStatus, $now, $reason): Entity {
                if ($targetStatus === self::STATUS_SENT) {
                    $execution->set('sentAt', $now->format('Y-m-d H:i:s'));
                }
                if ($targetStatus === self::STATUS_CANCELLED) {
                    $execution->set('cancelledAt', $now->format('Y-m-d H:i:s'));
                    $execution->set('cancelledById', $this->user->getId());
                    $execution->set('cancelReason', $reason);
                }

                $execution->set('status', $targetStatus);
                $this->entityManager->saveEntity($execution, [
                    StatusMutationSaveOption::SEND_EXECUTION_STATUS_MUTATION_AUTHORIZED => true,
                ]);
                $this->afterTransition($execution, $currentStatus, $targetStatus);

                return $execution;
            }
        );
    }

    /**
     * @param array{
     *   providerName?: string|null,
     *   providerMessageId?: string|null,
     *   lastError?: string|null,
     *   failureCategory?: string|null,
     *   retryCount?: int,
     *   now?: DateTimeImmutable|string
     * } $providerTrace
     */
    private function applyProviderTraceFields(Entity $execution, array $providerTrace): void
    {
        foreach (['providerName', 'providerMessageId', 'lastError', 'failureCategory', 'retryCount'] as $field) {
            if (array_key_exists($field, $providerTrace)) {
                $execution->set($field, $providerTrace[$field]);
            }
        }
    }

    /**
     * Extension hook for future side effects (notifications, queue fan-out).
     * Audit timestamp for SENT is applied before save in transition().
     */
    protected function afterTransition(Entity $execution, string $fromStatus, string $toStatus): void
    {
    }

    private function assertRetryAllowed(Entity $execution): void
    {
        $retryCount = (int) ($execution->get('retryCount') ?? 0);
        $maxRetries = (int) ($execution->get('maxRetries') ?? 0);
        if ($retryCount >= $maxRetries) {
            throw new BadRequest('SendExecution retry limit reached for maxRetries.');
        }
    }

    private function normalizeCancelReason(mixed $reason): string
    {
        $reason = strtoupper(trim((string) $reason));
        if (!in_array($reason, self::CANCEL_REASONS, true)) {
            throw new BadRequest('SendExecution cancel requires a valid cancelReason.');
        }

        return $reason;
    }

    /**
     * @param array{now?: DateTimeImmutable|string} $options
     */
    private function resolveNow(array $options): DateTimeImmutable
    {
        $now = $options['now'] ?? new DateTimeImmutable();
        if (is_string($now)) {
            $now = new DateTimeImmutable($now);
        }
        if (!$now instanceof DateTimeImmutable) {
            throw new BadRequest('Invalid SendExecution transition clock.');
        }

        return $now;
    }

    private function assertKnownStatus(string $status): void
    {
        if (!array_key_exists($status, self::VALID_TRANSITIONS)) {
            throw new BadRequest("Unknown SendExecution status: {$status}.");
        }
    }
}
